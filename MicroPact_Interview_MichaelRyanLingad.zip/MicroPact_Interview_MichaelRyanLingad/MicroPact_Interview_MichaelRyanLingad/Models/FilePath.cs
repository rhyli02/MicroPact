﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MicroPact_Interview_MichaelRyanLingad.Models
{
    public class FilePath
    {
        public int FileId { get; set; }
        public string FullPath { get; set; }
        public string FileName { get; set; }
        public bool ReadOnly { get; set; }
        public string Size { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}

﻿using MicroPact_Interview_MichaelRyanLingad.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MicroPact_Interview_MichaelRyanLingad.Data
{
    public class ValuesRepository
    {
        private readonly string _connectionString;
        public ValuesRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("defaultConnection");
        }

        public async Task<List<FilePath>> GetAll()
        {
            using(SqlConnection sql = new SqlConnection(_connectionString))
            {
                using(SqlCommand cmd = new SqlCommand("usp_GetAllData", sql)) 
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    var response = new List<FilePath>();
                    await sql.OpenAsync();

                    using(var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            response.Add(MapToValue(reader));
                        }
                    }
                    return response;
                
                }

            }
           

        }

        private FilePath MapToValue(SqlDataReader reader)
        {
            return new FilePath()
            {
                FileId = (int)reader["FileId"],
                FullPath = (string)reader["FullPath"].ToString(),
                FileName = (string)reader["FileName"].ToString(),
                ReadOnly = (bool)reader["ReadOnly"],
                Size = (string)reader["Size"].ToString(),
                CreatedDate = (DateTime)reader["CreatedDate"]
            };
        }

        public async Task<List<FilePath>> GetByCriteria(string criteria)
        {
            using (SqlConnection sql = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("usp_FileSearch", sql))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@criteria", criteria));
                    var response = new List<FilePath>();
                    await sql.OpenAsync();

                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            response.Add(MapToValue(reader));
                        }
                    }
                    return response;

                }

            }

        }

    }
}

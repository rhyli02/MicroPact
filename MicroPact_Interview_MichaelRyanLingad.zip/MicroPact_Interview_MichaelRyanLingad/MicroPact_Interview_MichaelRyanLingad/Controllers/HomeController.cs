﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MicroPact_Interview_MichaelRyanLingad.Models;
using MicroPact_Interview_MichaelRyanLingad.Data;

namespace MicroPact_Interview_MichaelRyanLingad.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ValuesRepository _repository;

        public HomeController(ILogger<HomeController> logger, ValuesRepository repository)
        {

            _logger = logger;
            _repository = repository;
        }
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var AllItems = await _repository.GetAll();
             return View(AllItems);
        }
        [HttpPost]
        public async Task<IActionResult> FilterByCriteria(string criteria)
        {
            var FilteredItem = await _repository.GetByCriteria(criteria);
            return View("Index",FilteredItem);
        }


        public async Task<IActionResult> WithUIFilter()
        {
            var AllItems = await _repository.GetAll();

            return View(AllItems);
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
